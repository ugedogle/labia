#agafar documents dels analistes i saber interpretarlos i donar un analisis en base a la pregunta feta.
#pugui complementar les dades tretes del SQL.

