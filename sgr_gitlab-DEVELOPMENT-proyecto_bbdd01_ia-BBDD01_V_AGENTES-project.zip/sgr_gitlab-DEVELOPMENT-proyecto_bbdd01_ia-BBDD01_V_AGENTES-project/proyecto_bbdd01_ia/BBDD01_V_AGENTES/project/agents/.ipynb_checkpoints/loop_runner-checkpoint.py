# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Any, Dict, List, Optional

import pandas as pd
from google.cloud import bigquery

from agents.orchestrator import Orchestrator
from agents.sql_agent import build_sql_from_plan
from agents.data_auditor import audit_dataset
from agents.viz_agent import pick_spec
from agents.artifact_auditor import audit_visual
from agents.composer import compose_response
from agents.final_auditor import final_check
from agents.web_agent import WebAgent

from tools.bigquery_tools import execute_sql
from tools.security import maybe_mask_dataframe
from tools.audit_log import log_interaction

from config.settings import PROJECT_ID, BQ_LOCATION, TABLA_BASE_FQN


def _is_cost_error(err: Exception) -> bool:
    msg = str(err).lower()
    return ("costosa" in msg) or ("bytes" in msg and ">" in msg)


def _get_min_max_mes() -> tuple[Optional[int], Optional[int]]:
    try:
        client = bigquery.Client(project=PROJECT_ID, location=BQ_LOCATION)
        q = f"SELECT MIN(CAST(MES AS INT64)) AS min_mes, MAX(CAST(MES AS INT64)) AS max_mes FROM {TABLA_BASE_FQN}"
        row = list(client.query(q).result())[0]
        return (int(row["min_mes"]) if row["min_mes"] is not None else None,
                int(row["max_mes"]) if row["max_mes"] is not None else None)
    except Exception:
        return (None, None)


def _looks_web_only(query: str) -> bool:
    q = (query or "").lower()
    kws = ["noticia", "noticias", "última hora", "hoy", "esta semana", "opa", "oferta", "bbva", "sabadell", "fed", "inflación", "macro"]
    hints_data = ["riesgo", "mes", "top", "tabla", "gráfico", "sum(", "avg(", "count("]
    return any(k in q for k in kws) and not any(h in q for h in hints_data)


class ChatRunner:
    def __init__(self, model: str = "gemini-2.5-pro", temperature: float = 0.2):
        self.model = model
        self.temperature = temperature

        self._orc = Orchestrator(model=self.model, temperature=self.temperature)
        self._web = WebAgent(model=self.model, temperature=self.temperature)

    def answer(self, user_query: str, show_plotly_inline=None, prefer_web: bool = False, web_only: bool = False):
        notes: List[str] = []
        plan = self._orc.plan(user_query, prefer_web=(prefer_web or web_only))

        # Fast-path: sólo web (no toca BQ)
        if web_only or _looks_web_only(user_query) or (getattr(plan, "need_sql", True) is False and getattr(plan, "need_web", False)):
            web_ctx = self._web.search_and_summarize(user_query, max_results=5)
            text_raw = compose_response(plan, df=None, stats={}, notes=["web-only"], spec={}, web_ctx=web_ctx)
            text = final_check(text_raw)
            log_interaction(stage="final", intent=user_query,
                            plan=plan.model_dump() if hasattr(plan, "model_dump") else dict(plan),
                            sql=None, stats=None, notes=["web-only"],
                            sources_web=[s.get("url") for s in (web_ctx.get("sources") or [])])
            return {"text": text, "sql": None, "df": None, "notes": ["web-only"], "web": web_ctx}

        # 1) SQL
        build = build_sql_from_plan(plan)
        sql = build.sql
        if build.notes:
            notes.extend(build.notes)

        # 2) Ejecutar (con fallback si es costosa)
        try:
            res = execute_sql(sql)
        except Exception as e:
            if _is_cost_error(e):
                _min_mes, _max_mes = _get_min_max_mes()
                if _max_mes:
                    # fuerza 1 mes y reintenta
                    if not hasattr(plan, "filters") or plan.filters is None:
                        plan.filters = {}
                    plan.filters["MES"] = {"type": "range_ym", "from": str(_max_mes), "to": str(_max_mes)}
                    build = build_sql_from_plan(plan)
                    sql = build.sql
                    if build.notes:
                        notes.extend(build.notes)
                    notes.append(f"Consulta costosa; ajustada a 1 mes {_max_mes}.")
                    res = execute_sql(sql)
                else:
                    raise
            else:
                raise

        stats = res.get("stats", {}) if isinstance(res, dict) else {}
        rows = res.get("rows", []) if isinstance(res, dict) else []
        df = pd.DataFrame(rows)

        # 3) Auditoría de datos
        da = audit_dataset(df=df, plan=plan)
        if not da.get("ok", True):
            fb = da.get("feedback") or "Consulta no óptima."
            notes.append(fb)
            # devolvemos texto con la auditoría
            text_raw = compose_response(plan, df=df, stats=stats, notes=notes, spec={}, web_ctx=None)
            text = final_check(text_raw)
            log_interaction(stage="auditor", intent=user_query,
                            plan=plan.model_dump() if hasattr(plan, "model_dump") else dict(plan),
                            sql=sql, stats=stats, notes=notes)
            return {"text": text, "sql": sql, "df": df.to_dict(orient="records"), "notes": notes}

        # 4) Visual + auditor de artefacto
        spec = pick_spec(df=df, plan=plan)
        aa = audit_visual(df=df, spec=spec)
        spec = aa.get("spec", spec)
        if aa.get("notes"):
            notes.extend(aa["notes"])

        # Render (si el caller lo pasa)
        if show_plotly_inline and spec:
            try:
                # Si tienes tools.viz.render_chart úsalo; si no, sólo dejamos el texto.
                from tools.viz import render_chart
                render_chart(df=df, spec=spec, show_plotly_inline=show_plotly_inline)
            except Exception as e:
                notes.append(f"Visual no disponible: {e}")

        # 4.b) Contexto externo opcional
        web_ctx = None
        if bool(getattr(plan, "need_web", False) or prefer_web):
            try:
                qtxt = (getattr(plan, "intent", None) or user_query or "").strip()
                web_ctx = self._web.search_and_summarize(qtxt, max_results=5)
            except Exception as e:
                notes.append(f"Contexto externo no disponible: {e}")

        # 5) PII policy (en tu caso, allow, pero mantenemos el hook)
        try:
            df_masked = maybe_mask_dataframe(df, policy="allow")
        except Exception:
            df_masked = df

        # 6) Compose + Final audit
        text_raw = compose_response(plan, df=df_masked, stats=stats, notes=notes, spec=spec, web_ctx=web_ctx)
        text = final_check(text_raw)

        # 7) Audit log
        log_interaction(stage="final", intent=user_query,
                        plan=plan.model_dump() if hasattr(plan, "model_dump") else dict(plan),
                        sql=sql, stats=stats, notes=notes,
                        sources_web=[s.get("url") for s in (web_ctx.get("sources") or [])] if web_ctx else None)

        return {"text": text, "sql": sql, "df": df_masked.to_dict(orient="records"), "notes": notes}
