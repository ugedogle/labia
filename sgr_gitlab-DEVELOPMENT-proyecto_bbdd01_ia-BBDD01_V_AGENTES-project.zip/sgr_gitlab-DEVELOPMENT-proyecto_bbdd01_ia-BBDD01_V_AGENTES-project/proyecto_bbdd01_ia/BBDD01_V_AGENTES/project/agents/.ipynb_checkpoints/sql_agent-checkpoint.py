
# -*- coding: utf-8 -*-
"""
SQL Agent (robusto)
- Transforma un Plan en SQL Standard SEGURO sobre la tabla permitida.
- Mejora:
  * Auto-resuelve dimensiones desconocidas a sinónimos o "closest match" (con nota).
  * Ignora alias tras AS al validar métricas (evita fallos con "AS RIESGO").
"""

from __future__ import annotations
import re, difflib
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

from config.settings import TABLA_BASE_FQN
from tools.bigquery_tools import list_columns

# Flags de comportamiento
AUTO_FUZZY_DIM_MATCH = True    # intenta corregir dimensiones no encontradas
SUGGESTION_TOP_N = 3

# Sinónimos permitidos por negocio (ajustables)
SYNONYMS: Dict[str, List[str]] = {
    # ejemplo: peticiones de "sector" → columnas reales disponibles
    "SECTOR_ESTRATEGICO": ["SECTOR_COV19", "CALIFICACION_GRUPO", "COD_CNAE", "DESC_CNAE"],
    "SECTOR": ["SECTOR_COV19", "CALIFICACION_GRUPO", "COD_CNAE", "DESC_CNAE"],
}

# ------------------ helpers ------------------

def _current_year() -> int:
    return datetime.now().year

def _ci_equal(a: str, b: str) -> bool:
    return (a or "").strip().upper() == (b or "").strip().upper()

def _resolve_dim(dim: str, cols: List[str]) -> Tuple[str, Optional[str]]:
    """
    Devuelve (nombre_col_valido, nota) o levanta ValueError si no hay forma.
    1) Coincidencia exacta
    2) Coincidencia case-insensitive
    3) Sinónimos mapeados si existen
    4) Fuzzy: closest match (difflib)
    """
    if dim in cols:
        return dim, None

    # case-insensitive
    for c in cols:
        if _ci_equal(dim, c):
            return c, None

    # sinónimos por negocio
    for syn in SYNONYMS.get(dim, []):
        # exacta
        if syn in cols:
            return syn, f"Dimensión '{dim}' mapeada a sinónimo '{syn}'."
        # case-insensitive
        for c in cols:
            if _ci_equal(syn, c):
                return c, f"Dimensión '{dim}' mapeada a sinónimo '{c}'."

    # fuzzy (closest match)
    if AUTO_FUZZY_DIM_MATCH:
        suggs = difflib.get_close_matches(dim, cols, n=1)
        if suggs:
            return suggs[0], f"Dimensión '{dim}' auto-resuelta a '{suggs[0]}' (closest match)."

    # si llegamos aquí, no hay resolución
    raise ValueError(f"Dimensión no encontrada: {dim}. ¿Quizá quisiste: {difflib.get_close_matches(dim, cols, n=SUGGESTION_TOP_N)}?")

def _extract_metric_alias(expr: str) -> Optional[str]:
    m = re.search(r'\bAS\s+([A-Za-z_][A-Za-z0-9_]*)\b', expr, flags=re.IGNORECASE)
    return m.group(1) if m else None

def _cols_referenced_in_metric(expr: str) -> List[str]:
    """
    Devuelve posibles columnas referenciadas en la métrica.
    Importante: ignora el alias tras 'AS <alias>'.
    """
    # elimina todo lo que venga después de AS <alias>
    expr_no_alias = re.split(r'\bAS\b', expr, flags=re.IGNORECASE)[0]
    tokens = re.findall(r'[A-Za-z_][A-Za-z0-9_]*', expr_no_alias)
    funcs = {'SUM','AVG','COUNT','MIN','MAX','CAST','DISTINCT','CASE','WHEN','THEN','ELSE','END','NULL','IF','AND','OR','NOT'}
    # filtra funciones/keywords y números
    return [t for t in tokens if t.upper() not in funcs]

def _build_mes_filter(filters: Dict[str, Any]) -> Optional[str]:
    f = filters.get('MES') if isinstance(filters, dict) else None
    if not f:
        return None

    def ym_int(s: str|int) -> int:
        s = int(s)
        if s < 190001 or s > 299912:
            raise ValueError(f"MES fuera de rango YYYYMM: {s}")
        return s

    t = f.get('type')
    if t == 'range_ym':
        y1 = ym_int(f.get('from'))
        y2 = ym_int(f.get('to'))
        return f"CAST(MES AS INT64) BETWEEN {y1} AND {y2}"
    if t == 'between_year':
        y = int(f.get('year'))
        return f"CAST(MES AS INT64) BETWEEN {y}01 AND {y}12"
    if t == 'year':
        y = f.get('year')
        if isinstance(y, str) and y.lower() == 'this':
            y = _current_year()
        y = int(y)
        return f"CAST(MES AS INT64) BETWEEN {y}01 AND {y}12"
    if 'from' in f and 'to' in f:
        y1 = ym_int(f['from']); y2 = ym_int(f['to'])
        return f"CAST(MES AS INT64) BETWEEN {y1} AND {y2}"
    return None

def _quote_fqn(fqn: str) -> str:
    s = fqn.strip()
    if s.startswith('`') and s.endswith('`'):
        return s
    if len(s.split('.')) == 3:
        return f"`{s}`"
    return s

# ------------------ core ------------------

@dataclass
class SqlBuildResult:
    sql: str
    used_table: str
    dims: List[str]
    metrics: List[str]
    order_by: List[str]
    limit: int
    notes: List[str]

def build_sql_from_plan(plan, table_fqn: Optional[str]=None) -> SqlBuildResult:
    """
    Genera SQL Standard a partir del Plan. Valida columnas con el esquema real.
    - Auto-resuelve dimensiones desconocidas (sinónimos o closest match) y lo deja en 'notes'.
    - Ignora alias tras AS en validación de métricas.
    """
    tbl = _quote_fqn((table_fqn or (plan.tables[0] if plan.tables else TABLA_BASE_FQN)).strip())
    cols = list_columns(tbl)

    notes: List[str] = []

    # 1) Dimensiones
    dims: List[str] = []
    for d in plan.dimensions or []:
        resolved, note = _resolve_dim(d, cols)
        dims.append(resolved)
        if note:
            notes.append(note)

    # 2) Métricas (validación suave de columnas referenciadas)
    metrics_exprs: List[str] = []
    for m in plan.metrics or []:
        e = m.strip()
        # validar columnas referenciadas (sin alias)
        for ref in _cols_referenced_in_metric(e):
            # si ref no es columna exacta, prueba case-insensitive
            if ref not in cols and not any(_ci_equal(ref, c) for c in cols):
                # si parece nombre de columna, sugiere
                if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', ref):
                    sugg = difflib.get_close_matches(ref, cols, n=SUGGESTION_TOP_N)
                    raise ValueError(f"Columna en métrica no encontrada: {ref}. ¿Quizá: {sugg}?")
        metrics_exprs.append(e)

    # 3) WHERE (MES)
    where_clauses: List[str] = []
    mes_filter = _build_mes_filter(plan.filters or {})
    if mes_filter:
        where_clauses.append(mes_filter)

    # 4) SELECT
    select_parts: List[str] = []
    if dims:
        select_parts.extend(dims)
    select_parts.extend(metrics_exprs)
    select_sql = ",\n  ".join(select_parts)

    # 5) FROM + WHERE
    where_sql = ""
    if where_clauses:
        where_sql = "\nWHERE " + " AND ".join(where_clauses)

    # 6) GROUP BY (si hay dims)
    group_sql = ""
    if dims:
        group_sql = "\nGROUP BY " + ", ".join(dims)

    # 7) ORDER BY (alias o campos)
    order_parts: List[str] = []
    if plan.ordering:
        for o in plan.ordering:
            by = o.by
            dir_ = getattr(o, "dir", "DESC").upper()
            order_parts.append(f"{by} {dir_}")
    order_sql = ("\nORDER BY " + ", ".join(order_parts)) if order_parts else ""

    # 8) LIMIT
    lim = int(getattr(plan, "limit", 200) or 200)
    limit_sql = f"\nLIMIT {lim}"

    sql = f"""
SELECT
  {select_sql}
FROM {tbl}{where_sql}{group_sql}{order_sql}{limit_sql}
""".strip()

    return SqlBuildResult(
        sql=sql, used_table=tbl, dims=dims, metrics=metrics_exprs,
        order_by=order_parts, limit=lim, notes=notes
    )
