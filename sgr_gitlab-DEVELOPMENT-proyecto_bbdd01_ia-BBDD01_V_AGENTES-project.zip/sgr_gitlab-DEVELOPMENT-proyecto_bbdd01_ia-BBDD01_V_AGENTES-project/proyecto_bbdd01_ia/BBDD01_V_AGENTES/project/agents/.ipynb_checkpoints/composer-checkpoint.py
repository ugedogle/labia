# -*- coding: utf-8 -*-
from __future__ import annotations
import pandas as pd
from typing import List, Dict, Any

def _fmt_num(x) -> str:
    try:
        return f"{float(x):,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")
    except Exception:
        return str(x)

def _infer_period(plan) -> str:
    try:
        mes = getattr(plan, "filters", {}).get("MES")
        if isinstance(mes, dict) and mes.get("from") and mes.get("to"):
            return f"{mes.get('from')}–{mes.get('to')}"
    except Exception:
        pass
    return "N/D"

def _pick_category_col(df: pd.DataFrame) -> str | None:
    # Elige la 1ª columna no numérica distinta de 'RIESGO' / 'MES'
    for c in df.columns:
        if c not in ("RIESGO", "MES") and df[c].dtype == object:
            return c
    # Si no hay object, intenta la 1ª distinta de 'RIESGO' / 'MES'
    for c in df.columns:
        if c not in ("RIESGO", "MES"):
            return c
    return None

def compose_response(plan, df: pd.DataFrame | None, stats: Dict[str, Any], notes: List[str], spec: Dict[str, Any]) -> str:
    title = plan.intent or "Resultado"
    period = _infer_period(plan)
    lines = [f"### {title}", f"**Periodo:** {period}"]

    if stats:
        estb = stats.get("estimated_bytes")
        rows = stats.get("total_rows")
        if estb is not None or rows is not None:
            parts = []
            if estb is not None: parts.append(f"coste estimado ≈ {estb} bytes")
            if rows is not None: parts.append(f"filas devueltas = {rows}")
            if parts:
                lines.append("**Ejecución:** " + " · ".join(parts))

    if df is None or df.empty:
        lines.append("**Aviso:** la consulta no devolvió filas en el rango seleccionado.")
    else:
        # Resumen según espec
        if spec.get("type") == "line" and "RIESGO" in df.columns:
            n = len(df)
            vmin = df["RIESGO"].min()
            vmax = df["RIESGO"].max()
            lines.append(f"**Serie temporal:** {n} puntos · min={_fmt_num(vmin)} M€ · max={_fmt_num(vmax)} M€")
        else:
            # Top-3 por categoría si existe
            cat = _pick_category_col(df)
            if cat and "RIESGO" in df.columns:
                top3 = df.sort_values("RIESGO", ascending=False).head(3)[[cat, "RIESGO"]]
                bullets = [f"- **{row[cat]}**: {_fmt_num(row['RIESGO'])} M€" for _, row in top3.iterrows()]
                lines.append("**Top-3:**\n" + "\n".join(bullets))

    if notes:
        lines.append("**Notas:** " + " | ".join(notes))

    # Recordatorio de unidades (ya estamos mostrando M€)
    lines.append("_Unidades: millones de euros (M€)._")
    return "\n".join(lines)
